package com.simplejava.gui;

import com.simplejava.model.Player;
import com.simplejava.model.Team;
import com.simplejava.service.PlayerService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 */
public class FootballGuiMainView extends JPanel{

  private boolean DEBUG = false;

  PlayerService service=new PlayerService();


  public FootballGuiMainView() {
    super(new GridLayout(1,0));

    String[] columnNames = {"Email",
      " Name",
      "team"
    };

    service.aaaPlayer(new Player("test","id","email",new Team("team")));
    service.aaaPlayer(new Player("test2","id","email",new Team("team")));
    service.aaaPlayer(new Player("tes34","id","email",new Team("team")));

    final JTable table = new JTable(service.getAll(), columnNames);
    table.setPreferredScrollableViewportSize(new Dimension(600, 370));
    table.setFillsViewportHeight(true);

    if (DEBUG) {
      table.addMouseListener(new MouseAdapter() {
        public void mouseClicked(MouseEvent e) {
          printDebugData(table);
        }
      });
    }

    //Create the scroll pane and add the table to it.
    JScrollPane scrollPane = new JScrollPane(table);
    JButton b1 = new JButton("Add");
    b1.setVerticalTextPosition(AbstractButton.CENTER);
    b1.setHorizontalTextPosition(AbstractButton.LEADING); //aka LEFT, for left-to-right locales
    b1.setActionCommand("disable");
    b1.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
      }
    });
    add(b1);
    JButton saveButton = new JButton("Save");
    saveButton.setVerticalTextPosition(AbstractButton.CENTER);
    saveButton.setHorizontalTextPosition(AbstractButton.LEADING); //aka LEFT, for left-to-right locales
    saveButton.setActionCommand("disable");
    add(saveButton);
    //Add the scroll pane to this panel.
    add(scrollPane);
  }

  private void printDebugData(JTable table) {
    int numRows = table.getRowCount();
    int numCols = table.getColumnCount();
    javax.swing.table.TableModel model = table.getModel();

    System.out.println("Value of data: ");
    for (int i=0; i < numRows; i++) {
      System.out.print("    row " + i + ":");
      for (int j=0; j < numCols; j++) {
        System.out.print("  " + model.getValueAt(i, j));
      }
      System.out.println();
    }
    System.out.println("--------------------------");
  }


  /**
   * Create the GUI and show it.  For thread safety,
   * this method should be invoked from the
   * event-dispatching thread.
   */
  private static void createAndShowGUI() {
    //Create and set up the window.
    JFrame frame = new JFrame("SimpleTableDemo");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    //Create and set up the content pane.
    FootballGuiMainView newContentPane = new FootballGuiMainView();
    newContentPane.setOpaque(true); //content panes must be opaque
    frame.setContentPane(newContentPane);

    //Display the window.
    frame.pack();
    frame.setVisible(true);
  }


  public static void main(String[] args) {
    javax.swing.SwingUtilities.invokeLater(new Runnable() {
      public void run() {
        createAndShowGUI();
      }
    });
  }
}
