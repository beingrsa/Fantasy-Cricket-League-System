package com.simplejava.service;

import com.simplejava.model.Player;

import java.util.ArrayList;
import java.util.List;

/**
 */
public class PlayerService {

  private List<Player> players;


  public PlayerService() {
    players=new ArrayList<>();
  }


  public void aaaPlayer(Player player){
    players.add(player);
  }

  public void removePlayer(){

  }

  public void updatePlayer(){

  }

  // Replace with tableModel.
  public  Object[][] getAll(){
    Object[][] data=new Object[players.size()][4];
    int iteration=0;
    for(Player p:players){
        data[iteration][0]=p.getEmail();
        data[iteration][2]=p.getName();
        data[iteration][3]=p.getTeam().getName();
        iteration++;
    }
    return data;
  }


}
