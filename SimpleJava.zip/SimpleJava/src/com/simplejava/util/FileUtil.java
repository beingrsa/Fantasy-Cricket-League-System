package com.simplejava.util;

/**
 * Created by wtrocki on 10/7/16.
 */
public class FileUtil {

  // TODO Model save and read
}
